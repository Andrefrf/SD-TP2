package sys.storage;

public class DownloadDropArgs {
	@SuppressWarnings("unused")
    private final String path;

    public DownloadDropArgs(String path) {
        this.path = path;
    }
}
