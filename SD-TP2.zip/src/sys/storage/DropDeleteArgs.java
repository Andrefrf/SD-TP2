package sys.storage;

public class DropDeleteArgs {
	@SuppressWarnings("unused")
	private final String path;

    public DropDeleteArgs(String path) {
        this.path = path;
    }
}
